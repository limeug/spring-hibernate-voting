package ca.sheridancollege;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment2EugeneLimApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment2EugeneLimApplication.class, args);
	}

}
